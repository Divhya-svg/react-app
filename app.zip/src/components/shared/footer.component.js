import React,{Fragment} from 'react';

function Footer(props){
    return(
        <Fragment>
            <hr/>
            <small>
            &copy;EShopiee (www.EShopie.com)
            </small> 
        </Fragment>
    )
}
export default Footer;