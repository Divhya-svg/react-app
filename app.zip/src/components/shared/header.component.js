import React ,{Fragment} from 'react';

function Header(props){
    return(
        <Fragment>
            <h1>Register Here</h1>
            <hr/>
        </Fragment>
    )
}
export default Header;